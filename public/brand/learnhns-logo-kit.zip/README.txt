LearnHNS logo kit
=================

The mark is a head in profile with the Handshake H in mind — learning
the protocol. Same identity as the original LearnHNS icon, redrawn as
real vectors so it stays sharp at any size.

Use SVG whenever you can. PNG is included at 512 / 1024 / 2048 / 4096
for tools that want raster.

Files
-----
svg/
  learnhns-icon.svg              currentColor (inherits CSS color)
  learnhns-icon-white.svg
  learnhns-icon-black.svg
  learnhns-icon-violet.svg       Handshake violet #693AFA
  learnhns-wordmark-white.svg    icon + LearnHNS wordmark (outlined)
  learnhns-wordmark-black.svg

png/
  learnhns-icon-{white|black|violet}-{512,1024,2048,4096}.png
                                 transparent background
  learnhns-icon-white-on-black-2048.png
  learnhns-icon-black-on-white-2048.png
  learnhns-wordmark-white-2400.png
  learnhns-wordmark-black-2400.png

Color
-----
  Black     #111111
  White     #FFFFFF
  Violet    #693AFA    (Handshake / LearnHNS accent)
  Mint      #00F0C0    (accent only — not for the mark itself)

Usage
-----
  - Don't stretch, rotate, or add a drop shadow.
  - Keep clear space around the mark roughly equal to the neck width.
  - On dark backgrounds use the white mark. On light, use black.
  - Violet is optional for the whole mark. Don't recolor the H alone
    to a random palette.
  - The Handshake H inside the head is the Handshake protocol mark,
    used here as "HNS in mind." Don't replace it with another letter.

LearnHNS is independent and not affiliated with Handshake Foundation.
https://learnhns.com/about/
